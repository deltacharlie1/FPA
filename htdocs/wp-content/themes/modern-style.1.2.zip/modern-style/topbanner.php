<?php if(get_theme_option('topbanner') != '') {
	?>
	<div style="text-align: center; padding: 10px;">
		<?php echo(get_theme_option('topbanner')); ?>
	</div>
<?php } ?>