<?php get_header(); ?>
    		<div id="content">	
    			<h2 class="center">Error 404 - Page Not Found</h2>
    		</div>

        </div>

    <?php get_sidebar(); ?>
<?php get_footer(); ?>