    <div class="footer-a">
    
    	<div class="m">
        	
            <div class="get-up-and-running">
            
            	<h3>Get Up And Running <br /><strong>In Less Than 5 Minutes</strong></h3>
                
                <div class="listfix">
                
                    <ul>
                        <li class="one">Register<strong>60 sec</strong></li>
                        <li class="two">Activate<strong>5 sec</strong></li>
                        <li class="three">Login<strong>30 sec</strong></li>
                        <li class="four">Setup<strong>1m 30 sec</strong></li>
                        <li class="five">Get Started<strong>easy peasy</strong></li>
                        <li class="six"><a href="" title="register"></a></li>
                    </ul>
                    
                    <div class="clear"></div>
            	
                </div>
                            
            </div>
            
            <a href="" class="banner"></a>
    	
			<div class="clear"></div>
                
        </div>
        
		<div class="clear"></div>
    
    </div>
    
	<div class="clear"></div>

