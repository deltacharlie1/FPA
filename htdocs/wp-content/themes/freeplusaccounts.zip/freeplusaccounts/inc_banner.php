    <div class="banner" id="banner">
    
      <div class="m"><div class="banner-items"><img src="<?php bloginfo('template_directory'); ?>/images/banner-1.png" alt="Free Online Accountancy System" /></div></div>
      
      <div class="testimionials">
      
            <div class="m coda-slider-wrapper">
                <div class="coda-slider preload" id="testimionials">
    				<?php dynamic_sidebar( 'home-quotes' ); ?>
                </div>
            </div>
      
      </div>
    
    </div>
    