
    <div class="banner" id="banner">
    
      <div class="m"><div class="banner-items"><img src="<?php bloginfo('template_directory'); ?>/images/banner-1.png" alt="Free Online Accountancy System" /></div></div>
      
      <div class="testimionials">
      
            <div class="m">
                
              <object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="916" height="95">
                <param name="movie" value="<?php bloginfo('template_directory'); ?>/flash/animation-v1.swf" />
                <param name="quality" value="high" />
                <param name="wmode" value="transparent" />
                <param name="swfversion" value="9.0.0.0" />
                <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don’t want users to see the prompt. -->
                <param name="expressinstall" value="<?php bloginfo('template_directory'); ?>/Scripts/expressInstall.swf" />
                <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
                <!--[if !IE]>-->
                <object type="application/x-shockwave-flash" data="<?php bloginfo('template_directory'); ?>/flash/animation-v1.swf" width="916" height="95">
                  <!--<![endif]-->
                  <param name="quality" value="high" />
                  <param name="wmode" value="transparent" />
                  <param name="swfversion" value="9.0.0.0" />
                  <param name="expressinstall" value="<?php bloginfo('template_directory'); ?>/Scripts/expressInstall.swf" />
                  <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
                  <div>
                    <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
                    <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" width="112" height="33" /></a></p>
                  </div>
                  <!--[if !IE]>-->
                </object>
                <!--<![endif]-->
              </object>
              
        </div>
      
      </div>
    
    </div>
    