	Cufon('.post h3 a', { hover: true });
	Cufon('.whitecontainer h1');
	Cufon('.whitecontainer h2');
	Cufon('.whitecontainer h3');
	Cufon('.get-up-and-running h3');
	Cufon('.get-up-and-running ul li');
	Cufon('#nav a');
	Cufon('.footer-b .m  h3');
	Cufon('.footer-b .m  h4');