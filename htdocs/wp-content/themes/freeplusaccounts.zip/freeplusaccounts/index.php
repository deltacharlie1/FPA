<?php get_header(); ?>
    
    <div class="spacer clear line"></div>
    
    <div class="m whitecontainer">
    
    <h1>Woops!</h1>

	<p>There has been an error, <a href="<?php echo get_site_url(); ?>">click here</a> to go back to the home page.</p>
        
               
	</div>
    
    <!--- END WHITECONTAINER --->

<?php get_footer(); ?>