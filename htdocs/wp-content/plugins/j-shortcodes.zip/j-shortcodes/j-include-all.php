<?php

/*
                                ==============
                                 J Shortcodes
                                ==============

    Collection of userful shortcodes to enrich any Wordpress Theme, Blog and Website

                       +------------------------------+
                       |  http://www.jshortcodes.com  |
                       +------------------------------+
*/

include_once (ABSPATH . WPINC . '/feed.php');      // Support for [jrss] shortcode

require_once (dirname(__FILE__) . '/j-utils.php');
require_once (dirname(__FILE__) . '/j-admin.php');

?>