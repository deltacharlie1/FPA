<?php
/*
Simple:Press
Admin Permissions Support Functions
$LastChangedDate: 2010-03-26 23:38:27 +0000 (Fri, 26 Mar 2010) $
$Rev: 3818 $
*/

if (preg_match('#' . basename(__FILE__) . '#', $_SERVER['PHP_SELF']))
{
	die('Access Denied');
}

?>