tinyMCE.addI18n('nl.spoiler',{
	desc : 'Spoiler'
});
