tinyMCE.addI18n('hu.spoiler',{
	desc : 'Spoiler'
});
