tinyMCE.addI18n('fa.spoiler',{
	desc : 'Spoiler'
});
