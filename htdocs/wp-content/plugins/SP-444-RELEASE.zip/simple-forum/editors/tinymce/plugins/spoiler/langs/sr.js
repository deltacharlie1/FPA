tinyMCE.addI18n('sr.spoiler',{
	desc : 'Spoiler'
});
