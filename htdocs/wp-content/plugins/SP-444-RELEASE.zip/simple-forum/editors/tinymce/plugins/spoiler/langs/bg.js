tinyMCE.addI18n('bg.spoiler',{
	desc : 'Spoiler'
});
