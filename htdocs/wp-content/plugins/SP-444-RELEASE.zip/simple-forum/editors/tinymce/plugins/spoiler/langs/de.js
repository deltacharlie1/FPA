tinyMCE.addI18n('de.spoiler',{
	desc : 'Spoiler'
});
