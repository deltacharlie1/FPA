tinyMCE.addI18n('el.spoiler',{
	desc : 'Spoiler'
});
