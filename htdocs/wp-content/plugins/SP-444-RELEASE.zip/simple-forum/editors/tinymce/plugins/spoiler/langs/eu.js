tinyMCE.addI18n('eu.spoiler',{
	desc : 'Spoiler'
});
