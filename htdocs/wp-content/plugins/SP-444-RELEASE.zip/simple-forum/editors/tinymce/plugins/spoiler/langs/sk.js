tinyMCE.addI18n('sk.spoiler',{
	desc : 'Spoiler'
});
