tinyMCE.addI18n('be.spoiler',{
	desc : 'Spoiler'
});
