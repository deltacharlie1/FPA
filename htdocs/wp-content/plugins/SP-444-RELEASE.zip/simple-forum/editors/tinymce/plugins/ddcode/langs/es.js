tinyMCE.addI18n('es.ddcode',{
	desc 	: 'Syntax Highlighter',
	select 	: 'Select Code Type:'
});
