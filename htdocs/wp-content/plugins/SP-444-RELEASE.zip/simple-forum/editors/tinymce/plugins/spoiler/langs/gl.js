tinyMCE.addI18n('gl.spoiler',{
	desc : 'Spoiler'
});
