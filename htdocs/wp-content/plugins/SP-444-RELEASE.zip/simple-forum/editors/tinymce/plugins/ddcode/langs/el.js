tinyMCE.addI18n('el.ddcode',{
	desc 	: 'Syntax Highlighter',
	select 	: 'Select Code Type:'
});
