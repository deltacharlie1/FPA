tinyMCE.addI18n('en.spoiler',{
	desc : 'Spoiler'
});
