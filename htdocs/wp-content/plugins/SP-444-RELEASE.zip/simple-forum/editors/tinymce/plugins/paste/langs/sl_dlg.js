tinyMCE.addI18n('sl.paste_dlg',{
text_title:"Uporabite kombinacijo tipk CTRL+V, da prilepite vsebino v okno.",
text_linebreaks:"Obdr\u017Ei prelome vrstic",
word_title:"Uporabite kombinacijo tipk CTRL+V, da prilepite vsebino v okno."
});