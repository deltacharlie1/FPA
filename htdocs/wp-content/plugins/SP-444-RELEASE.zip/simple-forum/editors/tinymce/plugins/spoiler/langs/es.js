tinyMCE.addI18n('es.spoiler',{
	desc : 'Spoiler'
});
