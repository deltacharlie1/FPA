tinyMCE.addI18n('th.spoiler',{
	desc : 'Spoiler'
});
