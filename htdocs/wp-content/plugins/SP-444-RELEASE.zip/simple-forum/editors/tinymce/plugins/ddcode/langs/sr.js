tinyMCE.addI18n('sr.ddcode',{
	desc 	: 'Syntax Highlighter',
	select 	: 'Select Code Type:'
});
