tinyMCE.addI18n('zh.spoiler',{
	desc : 'Spoiler'
});
