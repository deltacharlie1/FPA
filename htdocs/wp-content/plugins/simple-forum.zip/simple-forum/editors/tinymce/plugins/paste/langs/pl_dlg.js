tinyMCE.addI18n('pl.paste_dlg',{
text_title:"U\u017Cyj CTRL+V na swojej klawiaturze \u017Ceby wklei\u0107 tekst do okna.",
text_linebreaks:"Zachowaj ko\u0144ce linii.",
word_title:"U\u017Cyj CTRL+V na swojej klawiaturze \u017Ceby wklei\u0107 tekst do okna."
});