tinyMCE.addI18n('it.spoiler',{
	desc : 'Spoiler'
});
