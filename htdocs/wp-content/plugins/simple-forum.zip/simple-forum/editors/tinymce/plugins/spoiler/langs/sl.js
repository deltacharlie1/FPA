tinyMCE.addI18n('sl.spoiler',{
	desc : 'Spoiler'
});
