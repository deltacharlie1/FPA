tinyMCE.addI18n('ro.spoiler',{
	desc : 'Spoiler'
});
