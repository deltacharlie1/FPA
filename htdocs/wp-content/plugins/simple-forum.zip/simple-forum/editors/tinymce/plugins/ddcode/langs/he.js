tinyMCE.addI18n('he.ddcode',{
	desc 	: 'Syntax Highlighter',
	select 	: 'Select Code Type:'
});
