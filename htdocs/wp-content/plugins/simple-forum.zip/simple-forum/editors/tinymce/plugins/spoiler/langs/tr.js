tinyMCE.addI18n('tr.spoiler',{
	desc : 'Spoiler'
});
