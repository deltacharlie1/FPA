tinyMCE.addI18n('ar.spoiler',{
	desc : 'Spoiler'
});
