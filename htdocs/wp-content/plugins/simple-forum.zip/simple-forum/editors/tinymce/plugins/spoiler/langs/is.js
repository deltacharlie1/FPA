tinyMCE.addI18n('is.spoiler',{
	desc : 'Spoiler'
});
