tinyMCE.addI18n('id.spoiler',{
	desc : 'Spoiler'
});
